import Testing

@Suite struct PlaceholderTests {
    @Test func placeholder() {
        #expect(true)
    }
}
